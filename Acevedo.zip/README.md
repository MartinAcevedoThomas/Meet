# Meet

Permette a più utenti di connetersi, condividendo il proprio schermo.
Con la possibilità di disattivare il video o l'audio

L'app è gestita da un server node con all'interno un servizio web socket
